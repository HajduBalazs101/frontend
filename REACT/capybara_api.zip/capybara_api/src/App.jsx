import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'
import Header from './components/Header'
import Home from './pages/Home'
import Review from './pages/Review'
import Products from './pages/Products'
import About from './pages/About'

function App() {
  const [count, setCount] = useState(0)
  let path = location.pathname
  return (
    <>
       <Header />

          {path === "/" && <Home />}
          {path === "/pages/About.jsx" && <About/>}
          {path === "/pages/Products.jsx" && <Products/>}
          {path === "/pages/Review.jsx" && <Review/>}


        <footer>
              <p>2025 Adorable Capybaras. All rights reserved.</p>
        </footer>
    </>
  )
}

export default App
