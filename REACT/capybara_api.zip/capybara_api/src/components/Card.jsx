import React from 'react'

export default function Card(props) {
  return (
        <div className="card" style={{width: "18rem", backgroundColor: props.Bgcolor}}>
            <img src="..." className="card-img-top" alt="..."/>
            <div className="card-body">
                <h5 className="card-title">{props.title}</h5>
                <a href={"../pages/" + props.link}  className="btn btn-primary">{props.title}</a>
            </div>
        </div>
)
}
